# Tutorial práctico — Sprint 1

## Fundamentos, configuración y Health

Este tutorial permite construir el Sprint 1 **desde un repositorio vacío**, sin depender de código previo.

Antes de comenzar, lea `SPRINT-01.md`. Allí se explican los conceptos que aquí se aplican.

> Regla del tutorial: cuando se indique “cree” o “reemplace” un archivo, utilice exactamente el contenido mostrado. No omita imports, no mezcle versiones parciales y no trabaje dentro de la carpeta `solucion-referencia` del material entregado.

---

# 0. Qué va a construir

Al finalizar tendrá este repositorio:

```text
api-alojamientos/
│
├── app/
│   ├── __init__.py
│   └── config.py
│
├── scripts/
│   ├── __init__.py
│   └── verificar_mysql.py
│
├── tests/
│   ├── conftest.py
│   └── test_health.py
│
├── migrations/
│   └── ... archivos generados por Flask-Migrate/Alembic
│
├── docs/
│   └── postman/
│       ├── Alojamientos-API-Sprint-01.postman_collection.json
│       └── Alojamientos-API-Sprint-01.postman_environment.json
│
├── .env
├── .env.example
├── .gitignore
├── app.py
├── pytest.ini
├── README.md
└── requirements.txt
```

La aplicación expondrá:

```http
GET /health
```

---

# 1. Verificar herramientas antes de comenzar

Abra una terminal.

Compruebe Python:

```bash
python --version
```

Si su sistema utiliza `python3`:

```bash
python3 --version
```

Compruebe Git:

```bash
git --version
```

Compruebe el cliente de MySQL:

```bash
mysql --version
```

Compruebe que MySQL Server esté iniciado. La forma de iniciarlo depende de su sistema operativo o instalación.

Si dale mysql: command not found
normalmente significa que Windows no encuentra el ejecutable mysql.exe porque su carpeta no está agregada al PATH.

Abra Postman y confirme que puede crear Collections y Environments.

No continúe si Python, Git o MySQL no están disponibles en su equipo.

---

# 2. Preparar el repositorio Git

El repositorio de práctica es:

```text
https://github.com/oflodororni/api-alojamientos.git
```

Este repositorio parte vacío. El primer sprint necesita crear una rama `main` real antes de trabajar en una feature branch.

## 2.1 Crear la carpeta local

Windows PowerShell, Linux o macOS:

```bash
mkdir api-alojamientos
cd api-alojamientos
```

Inicialice Git:

```bash
git init
git config user.name "rodolfo"
git config user.email "oflodororngmail.com"
git branch -M maini@
```

Agregue el remoto:

```bash
git remote add origin https://github.com/oflodororni/api-alojamientos.git
```+

Verifique:

```bash
git remote -v
```

Debe aparecer `origin` apuntando a:

```text
https://github.com/oflodororni/api-alojamientos.git
```

> Si `git remote add origin` responde que `origin` ya existe, no vuelva a agregarlo. Use `git remote -v` para comprobarlo.

---

# 3. Crear el bootstrap inicial de `main`

Antes de crear `.env`, cree `.gitignore`. Esto evita versionar secretos por accidente.

Cree el archivo `.gitignore` en la raíz y pegue exactamente:

```text
.venv/
__pycache__/
*.py[cod]
.env
.pytest_cache/
.coverage
htmlcov/
.vscode/
.idea/
.DS_Store
```

Cree `README.md` en la raíz y pegue:

```markdown
# API Alojamientos

Proyecto académico para construir una API REST con Flask, MySQL, pruebas automatizadas y Postman mediante sprints progresivos.

## Sprints

- Sprint 1: fundamentos, configuración y health.
- Sprint 2: autenticación y autorización.
- Sprint 3: CRUD y relaciones.
```

Revise los archivos:

```bash
git status
```

Cree el primer commit de `main`:

```bash
git add .gitignore README.md
git commit -m "chore: inicializar repositorio de practica"
```

Publique `main`:

```bash
git push -u origin main
```

Ahora GitHub ya tiene una rama `main` que posteriormente podrá recibir el Pull Request del sprint.

## Si el repositorio ya no está vacío

Si el docente ya realizó este bootstrap antes de la clase, no repita los pasos anteriores. En ese caso clone el proyecto:

```bash
git clone https://github.com/oflodororni/api-alojamientos.git
cd api-alojamientos
```

Compruebe:

```bash
git branch --show-current
git remote -v
```

Debe estar sobre `main` y apuntar al remoto correcto.

---

# 4. Crear la Issue del sprint

En GitHub abra el repositorio y cree una Issue.

Título:

```text
Sprint 1: configurar base técnica y endpoint health
```

Descripción sugerida para copiar y pegar:

```markdown
## Objetivo
Configurar la base técnica de la API Alojamientos y crear el endpoint GET /health.

## Criterios de aceptación
- Flask inicia mediante App Factory.
- La configuración se obtiene desde variables de entorno.
- SQLAlchemy se conecta a MySQL mediante PyMySQL.
- Flask-Migrate/Alembic queda inicializado.
- CORS queda configurado.
- GET /health responde 200 y JSON esperado.
- pytest queda en verde.
- /health se valida en Postman.
- Collection y Environment de Postman se exportan al repositorio.
```

Cree la feature branch desde `main`:

```bash
git checkout main
git pull origin main
git checkout -b feat/sprint-01-fundamentos-health
```

Confirme:

```bash
git branch --show-current
```

Debe mostrar:

```text
feat/sprint-01-fundamentos-health
```

---

# 5. Crear y activar el entorno virtual

Desde la raíz `api-alojamientos/` ejecute:

```bash
python -m venv .venv
```

## Windows PowerShell

```powershell
.\.venv\Scripts\Activate.ps1
```

Si PowerShell bloquea scripts por política de ejecución, puede utilizar temporalmente:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

## Windows CMD

```bat
.venv\Scripts\activate.bat
```

## Linux/macOS

```bash
source .venv/Scripts/activate
```

Verifique que el Python activo pertenece al entorno:

```bash
python -c "import sys; print(sys.executable)"
```

La ruta debe apuntar a `.venv`.

ctrl + shift + p -> python: seleccionar intérprete -> .venv
---

# 6. Crear `requirements.txt`

Cree `requirements.txt` en la raíz y pegue:

```text
Flask==3.1.3
Flask-SQLAlchemy==3.1.1
Flask-CORS==6.0.2
Flask-Migrate==4.1.0
PyMySQL==1.1.2
python-dotenv==1.2.2
pytest==9.0.3
```

Instale las dependencias:

```bash
python -m pip install -r requirements.txt
```

Compruebe que Flask está disponible:

```bash
python -c "from importlib.metadata import version; print(version('Flask'))"
```

> Si el comando imprime una versión, Flask está instalado dentro del entorno virtual activo.

---

# 7. Crear la estructura de carpetas y archivos

No cree `migrations/` manualmente. Esa carpeta la generará Alembic más adelante.

## Windows PowerShell

```powershell
New-Item -ItemType Directory -Force -Path app, scripts, tests, docs, docs\postman | Out-Null
New-Item -ItemType File -Force -Path app\__init__.py, app\config.py, scripts\__init__.py, scripts\verificar_mysql.py, tests\conftest.py, tests\test_health.py, app.py, pytest.ini, .env.example | Out-Null
```

## Linux/macOS

```bash
mkdir -p app scripts tests docs/postman
touch app/__init__.py app/config.py
touch scripts/__init__.py scripts/verificar_mysql.py
touch tests/conftest.py tests/test_health.py
touch app.py pytest.ini .env.example
```

Compruebe la estructura.

Linux/macOS:

```bash
find . -maxdepth 2 -type f | sort
```

Windows PowerShell:

```powershell
Get-ChildItem -Recurse -File | Select-Object FullName
```

---

# 8. Crear `.env.example` y `.env`

Abra `.env.example` y pegue:

```env
# MySQL
DB_USER=root
DB_PASSWORD=
DB_HOST=localhost
DB_PORT=3306
DB_NAME=alojamientos_db

# CORS: orígenes permitidos separados por coma
CORS_ALLOWED_ORIGINS=http://localhost:5173,http://localhost:3000
```

Cree la copia local `.env`.

## Windows PowerShell

```powershell
Copy-Item .env.example .env
```

## Linux/macOS

```bash
cp .env.example .env
```

Abra `.env` y configure las credenciales reales de su MySQL. Ejemplo:

```env
DB_USER=root
DB_PASSWORD=admin
DB_HOST=localhost
DB_PORT=3307
DB_NAME=alojamientos_db
CORS_ALLOWED_ORIGINS=http://localhost:5173,http://localhost:3000
```

No copie la contraseña real de vuelta a `.env.example`.

Compruebe que Git está ignorando `.env`:

```bash
git check-ignore -v .env
```

El comando debe mostrar una regla proveniente de `.gitignore`.

Si ejecuta:

```bash
git status --short
```

`.env` **no debe aparecer**.

---

# 9. Crear la base de datos MySQL

Abra MySQL desde consola. Si usa `root`:

```bash
mysql -u root -p
```

Ingrese su contraseña cuando MySQL la solicite.

Dentro del cliente MySQL ejecute:

```sql
CREATE DATABASE IF NOT EXISTS alojamientos_db
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;
```

Verifique:

```sql
SHOW DATABASES LIKE 'alojamientos_db';
```

Debe aparecer:

```text
alojamientos_db
```

Salga:

```sql
EXIT;
```

Si su `.env` utiliza otro `DB_USER`, asegúrese de que ese usuario tenga permisos sobre `alojamientos_db`.

```sql
CREATE USER 'alojamientos_user'@'127.0.0.1' IDENTIFIED BY 'Alojamientos123!';
CREATE DATABASE IF NOT EXISTS alojamientos_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
GRANT ALL PRIVILEGES ON alojamientos_db.* TO 'alojamientos_user'@'127.0.0.1';
```
---

# 10. Implementar la configuración de Flask

Abra `app/config.py` y reemplace todo su contenido por:

```python
import os

from dotenv import load_dotenv
from sqlalchemy.engine import URL

load_dotenv()


class Config:
    """Configuración central de la aplicación."""

    SQLALCHEMY_TRACK_MODIFICATIONS = False

    _db_user = os.getenv("DB_USER", "root").strip()
    _db_password = os.getenv("DB_PASSWORD", "").strip()
    _db_host = os.getenv("DB_HOST", "localhost").strip()
    _db_port = int(os.getenv("DB_PORT", "3306").strip())
    _db_name = os.getenv("DB_NAME", "alojamientos_db").strip()

    SQLALCHEMY_DATABASE_URI = URL.create(
        drivername="mysql+pymysql",
        username=_db_user,
        password=_db_password,
        host=_db_host,
        port=_db_port,
        database=_db_name,
    ).render_as_string(hide_password=False)

    _cors = os.getenv(
        "CORS_ALLOWED_ORIGINS",
        "http://localhost:5173,http://localhost:3000",
    )
    CORS_ALLOWED_ORIGINS = [
        origen.strip() for origen in _cors.split(",") if origen.strip()
    ]
```

¿Por qué se utiliza `URL.create()` en lugar de concatenar manualmente la URL? Porque SQLAlchemy puede escapar correctamente caracteres especiales en usuario o contraseña.

El flujo es:

```text
.env
 ↓
load_dotenv()
 ↓
Config
 ↓
SQLALCHEMY_DATABASE_URI + CORS_ALLOWED_ORIGINS
```

---

# 11. Crear la App Factory sin `/health`

Abra `app/__init__.py` y reemplace todo su contenido por:

```python
from flask import Flask
from flask_cors import CORS
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy

from app.config import Config


db = SQLAlchemy()
migrate = Migrate()


def create_app():
    """Crea y configura la aplicación Flask."""
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    migrate.init_app(app, db)
    CORS(app, origins=app.config["CORS_ALLOWED_ORIGINS"])

    return app
```

En este momento `/health` todavía **no existe**. Esto es intencional porque primero escribiremos el comportamiento esperado con pytest.

---

# 12. Crear el punto de entrada `app.py`

Abra `app.py` y pegue:

```python
from app import create_app

app = create_app()

if __name__ == "__main__":
    app.run(debug=True, port=5000)
```

Pruebe que la aplicación puede arrancar:

```bash
python app.py
```

Debe ver un mensaje similar a:

```text
Running on http://127.0.0.1:5000
```

Detenga el servidor con:

```text
Ctrl + C
```

En este punto abrir `http://localhost:5000/health` produciría `404`. Es correcto: aún no hemos creado la ruta.

---

# 13. Verificar realmente la conexión Flask → SQLAlchemy → PyMySQL → MySQL

Crear la base en MySQL no demuestra que la aplicación pueda conectarse. Vamos a comprobar la conexión desde el mismo stack que usará la API.

Abra `scripts/__init__.py` y pegue:

```python
"""Scripts auxiliares del proyecto."""
```

Abra `scripts/verificar_mysql.py` y pegue:

```python
from sqlalchemy import text

from app import create_app, db


app = create_app()

with app.app_context():
    base_actual, version = db.session.execute(
        text("SELECT DATABASE(), VERSION()")
    ).one()

    print("Conexion MySQL correcta")
    print(f"Base de datos: {base_actual}")
    print(f"Version MySQL: {version}")
```

Ejecute desde la raíz del proyecto:

```bash
python -m scripts.verificar_mysql
```

Resultado esperado, con una versión que dependerá de su instalación:

```text
Conexion MySQL correcta
Base de datos: alojamientos_db
Version MySQL: ...
```

## Si falla

### `Access denied for user`

Revise `DB_USER` y `DB_PASSWORD` en `.env`.

### `Unknown database 'alojamientos_db'`

Vuelva al paso 9 y cree la base.

### `Can't connect to MySQL server`

Compruebe que MySQL Server esté iniciado y que `DB_HOST`/`DB_PORT` sean correctos.

### `No module named 'pymysql'`

Active `.venv` y ejecute nuevamente:

```bash
python -m pip install -r requirements.txt
```

No continúe con migraciones hasta que esta verificación funcione.

---

# 14. Inicializar Flask-Migrate/Alembic

Desde la raíz ejecute:

```bash
flask --app app.py db init
```

Debe aparecer una carpeta nueva:

```text
migrations/
├── versions/
├── alembic.ini
├── env.py
├── README
└── script.py.mako
```

Como Git no versiona carpetas vacías, cree un archivo `.gitkeep` dentro de `migrations/versions/`. Esto garantiza que el directorio exista cuando otro desarrollador clone el proyecto.

Windows PowerShell:

```powershell
New-Item -ItemType File -Force migrations\versions\.gitkeep | Out-Null
```

Linux/macOS:

```bash
touch migrations/versions/.gitkeep
```

Compruebe:

```bash
git status --short
```

`migrations/` debe aparecer como contenido nuevo que posteriormente será versionado.

**No ejecute todavía:**

```bash
flask --app app.py db migrate
```

No existen modelos de negocio. La primera migración real aparecerá en Sprint 2.

`db init` se ejecuta una sola vez por proyecto.

---

# 15. Configurar pytest

Abra `pytest.ini` y pegue:

```ini
[pytest]
testpaths = tests
python_files = test_*.py
pythonpath = .
```

Abra `tests/conftest.py` y pegue:

```python
import pytest

from app import create_app


@pytest.fixture
def app():
    aplicacion = create_app()
    aplicacion.config.update(TESTING=True)
    return aplicacion


@pytest.fixture
def client(app):
    return app.test_client()
```

`client` permite realizar peticiones HTTP de prueba contra Flask sin iniciar un servidor real.

---

# 16. Escribir los tests de `/health` antes de implementar la ruta

Abra `tests/test_health.py` y pegue exactamente:

```python
def test_health_responde_200(client):
    respuesta = client.get("/health")

    assert respuesta.status_code == 200


def test_health_responde_json_esperado(client):
    respuesta = client.get("/health")
    datos = respuesta.get_json()

    assert respuesta.content_type.startswith("application/json")
    assert datos == {
        "status": "ok",
        "service": "alojamientos-api",
        "version": "v1",
    }
```

Ejecute:

```bash
python -m pytest -q
```

Los tests deben fallar porque todavía no existe `/health`.

Debe observar fallos relacionados con `404 Not Found` y con una respuesta que todavía no contiene el JSON esperado.

Esto es intencional:

```text
criterio de aceptación
      ↓
test automatizado
      ↓
fallo esperado
      ↓
ahora implementamos
```

Si los tests pasan en este punto, revise que no haya agregado `/health` antes de tiempo.

---

# 17. Implementar `/health`

Ahora reemplace **todo** `app/__init__.py` por la versión final del Sprint 1:

```python
from flask import Flask
from flask_cors import CORS
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy

from app.config import Config

API_VERSION = "v1"

db = SQLAlchemy()
migrate = Migrate()


def create_app():
    """Crea y configura la aplicación Flask."""
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    migrate.init_app(app, db)
    CORS(app, origins=app.config["CORS_ALLOWED_ORIGINS"])

    @app.get("/health")
    def health():
        return {
            "status": "ok",
            "service": "alojamientos-api",
            "version": API_VERSION,
        }, 200

    return app
```

Observe el contrato:

```text
@app.get("/health")  → método GET + ruta /health
return {...}, 200     → JSON + status code
```

---

# 18. Ejecutar pytest nuevamente

Ejecute:

```bash
pytest -q
```

Resultado esperado:

```text
2 passed
```

Si falla, no continúe con Postman. Corrija primero la suite automatizada.

---

# 19. Agregar una prueba automatizada de CORS

Ahora agregaremos una comprobación específica de la configuración CORS.

Reemplace **todo** `tests/test_health.py` por:

```python
def test_health_responde_200(client):
    respuesta = client.get("/health")

    assert respuesta.status_code == 200


def test_health_responde_json_esperado(client):
    respuesta = client.get("/health")
    datos = respuesta.get_json()

    assert respuesta.content_type.startswith("application/json")
    assert datos == {
        "status": "ok",
        "service": "alojamientos-api",
        "version": "v1",
    }


def test_health_expone_cors_para_origen_permitido(client):
    respuesta = client.get(
        "/health",
        headers={"Origin": "http://localhost:5173"},
    )

    assert respuesta.headers.get("Access-Control-Allow-Origin") == (
        "http://localhost:5173"
    )
```

Ejecute nuevamente:

```bash
pytest -q
```

Resultado esperado:

```text
3 passed
```

Ahora tenemos tres comprobaciones automáticas:

```text
/health existe y responde 200
/health responde el JSON esperado
CORS reconoce un origen permitido
```

---

# 20. Ejecutar la API para la prueba manual

Inicie el servidor:

```bash
python app.py
```

Mantenga esta terminal abierta.

La API queda en:

```text
http://localhost:5000
```

Para los siguientes pasos abra una segunda terminal si necesita ejecutar otros comandos.

---

# 21. Crear el Environment en Postman

No importe una solución ya terminada. Crea una Collections Construya el Environment manualmente para comprender cómo se organiza Postman.

En Postman:

1. Abra **Environments**.
2. Seleccione **Create environment** o **New environment**.
3. Nombre:

```text
Alojamientos API - Sprint 01
```

4. Agregue la variable:

| Variable | Valor |
|---|---|
| `baseUrl` | `http://localhost:5000` |

5. Guarde el Environment.
6. Selecciónelo como Environment activo.

El objetivo es poder escribir URLs reutilizables:

```text
{{baseUrl}}/health
```

---

# 22. Crear la Collection y la request de Health

En Postman:

1. Cree una Collection.
2. Nombre:

```text
Alojamientos API - Sprint 01
```

3. Dentro cree una carpeta:

```text
Health
```

4. Dentro de `Health`, cree una request.
5. Nombre:

```text
GET /health
```

6. Seleccione método:

```text
GET
```

7. URL:

```text
{{baseUrl}}/health
```

8. No agregue Body.
9. Guarde la request.
10. Presione **Send**.

Debe observar:

```text
Status: 200 OK
```

Y un JSON equivalente a:

```json
{
  "service": "alojamientos-api",
  "status": "ok",
  "version": "v1"
}
```

El orden de claves JSON puede variar y no afecta el significado.

---

# 23. Verificar CORS desde Postman

Postman no bloquea peticiones por CORS, pero sí podemos enviar un `Origin` y observar qué responde Flask-CORS.

En la misma request `GET /health`:

1. Abra **Headers**.
2. Agregue:

```text
Key:   Origin
Value: http://localhost:5173
```

3. Presione **Send**.
4. Abra los **Response Headers**.
5. Busque:

```text
Access-Control-Allow-Origin: http://localhost:5173
```

Esto comprueba que la API está declarando ese origen como permitido.

Recuerde:

```text
Postman inspecciona CORS
pero no está sujeto a la política CORS del navegador
```

---

# 24. Exportar Postman al repositorio

La Collection y el Environment forman parte de la evidencia del sprint.

Asegúrese de que exista:

```text
docs/postman/
```

## Exportar Collection

En Postman:

1. Abra el menú de la Collection.
2. Seleccione **Export**.
3. Use Collection v2.1 si Postman solicita formato.
4. Guarde como:

```text
docs/postman/Alojamientos-API-Sprint-01.postman_collection.json
```

## Exportar Environment

1. Abra el menú del Environment `Alojamientos API - Sprint 01`.
2. Seleccione **Export**.
3. Guarde como:

```text
docs/postman/Alojamientos-API-Sprint-01.postman_environment.json
```

Compruebe desde consola:

Linux/macOS:

```bash
ls -la docs/postman
```

Windows PowerShell:

```powershell
Get-ChildItem docs\postman
```

Deben existir los dos archivos JSON.

> Nunca guarde contraseñas de MySQL dentro del Environment de Postman.

---

# 25. Validación técnica final antes de Git

Detenga el servidor con `Ctrl + C` si ya no lo necesita.

## 25.1 Verificar MySQL

```bash
python -m scripts.verificar_mysql
```

Debe conectar correctamente.

## 25.2 Ejecutar toda la suite

```bash
pytest -q
```

Debe terminar con:

```text
3 passed
```

## 25.3 Verificar que `.env` está ignorado

```bash
git check-ignore -v .env
```

## 25.4 Revisar archivos a versionar

```bash
git status --short
```

Debe ver archivos como:

```text
.env.example
app.py
app/
scripts/
tests/
migrations/
docs/postman/
pytest.ini
requirements.txt
```

No debe aparecer:

```text
.env
.venv/
__pycache__/
.pytest_cache/
```

---

# 26. Revisar el código antes del commit

Revise estas preguntas:

- ¿`app/config.py` obtiene la configuración desde variables de entorno?
- ¿`.env` está ignorado?
- ¿la contraseña real está únicamente en `.env`?
- ¿`create_app()` inicializa SQLAlchemy, Migrate y CORS?
- ¿`/health` devuelve `200` y JSON?
- ¿`pytest -q` muestra 3 tests exitosos?
- ¿la conexión MySQL funciona?
- ¿Postman obtuvo `200 OK`?
- ¿Postman mostró `Access-Control-Allow-Origin`?
- ¿los archivos de Postman fueron exportados?

Si alguna respuesta es “no”, corrija antes de continuar.

---

# 27. Commit del Sprint 1

Agregue los cambios:

```bash
git add .
```

Revise nuevamente:

```bash
git status
```

Compruebe especialmente que `.env` no esté en staging.

Realice el commit:

```bash
git commit -m "feat: completar fundamentos y health de la API"
```

---

# 28. Push obligatorio a GitHub

Publique la feature branch:

```bash
git push -u origin feat/sprint-01-fundamentos-health
```

Compruebe en GitHub que la rama existe.

El Sprint 1 **no se considera terminado si este push no fue realizado**.

---

# 29. Crear el Pull Request

En GitHub cree un Pull Request:

```text
base:    main
compare: feat/sprint-01-fundamentos-health
```

Título sugerido:

```text
Sprint 1: fundamentos, configuración y health
```

Descripción para copiar y pegar:

```markdown
## Qué se implementó
- Configuración mediante variables de entorno.
- Flask con App Factory.
- Flask-SQLAlchemy + PyMySQL + MySQL.
- Verificación de conexión a MySQL.
- Flask-Migrate/Alembic inicializado.
- CORS configurable.
- GET /health.
- Pruebas automatizadas con pytest.
- Collection y Environment de Postman.

## Cómo validar
1. Configurar `.env` a partir de `.env.example`.
2. Ejecutar `python -m scripts.verificar_mysql`.
3. Ejecutar `pytest -q`.
4. Ejecutar `python app.py`.
5. En Postman ejecutar `GET {{baseUrl}}/health`.

## Resultado esperado
- MySQL accesible desde SQLAlchemy/PyMySQL.
- pytest: 3 passed.
- GET /health: 200 OK.
```

Revise el diff del Pull Request antes del merge.

Confirme que `.env` no aparece en ningún cambio.

---

# 30. Sprint Review

Durante la Review muestre, en este orden:

```bash
python -m scripts.verificar_mysql
```

Luego:

```bash
pytest -q
```

Después inicie:

```bash
python app.py
```

Y muestre en Postman:

```http
GET {{baseUrl}}/health
```

Debe evidenciar:

- `200 OK`;
- JSON esperado;
- `Access-Control-Allow-Origin` al enviar `Origin` permitido;
- branch publicada;
- Pull Request.

---

# 31. Merge y cierre

Cuando el Pull Request cumpla los criterios y haya sido revisado, haga merge hacia `main`.

Después actualice su repositorio local:

```bash
git checkout main
git pull origin main
```

Verifique:

```bash
git log --oneline --decorate -5
```

`main` debe contener el Sprint 1.

El Sprint 2 partirá exactamente de este estado.

---

# 32. Retrospectiva

Responda brevemente:

1. ¿Qué salió bien?
2. ¿Qué configuración produjo mayor dificultad?
3. ¿Qué error detectó antes pytest, MySQL o Postman?
4. ¿Qué mejoraría para el Sprint 2?

---

# 33. Checklist final del estudiante

Antes de considerar terminada la práctica marque todo:

```text
[ ] main inicial existe en GitHub
[ ] Issue creada
[ ] feature branch creada
[ ] .venv creado y activo
[ ] dependencias instaladas
[ ] .gitignore creado
[ ] .env.example creado
[ ] .env local configurado y no versionado
[ ] alojamientos_db creada
[ ] Config implementada
[ ] App Factory implementada
[ ] SQLAlchemy y CORS inicializados
[ ] conexión MySQL verificada
[ ] Alembic inicializado
[ ] tests escritos antes de /health
[ ] fallo 404 observado
[ ] /health implementado
[ ] pytest muestra 3 passed
[ ] /health probado en Postman
[ ] CORS inspeccionado en Postman
[ ] Collection exportada
[ ] Environment exportado
[ ] git status revisado
[ ] commit realizado
[ ] push realizado
[ ] Pull Request creado
[ ] Sprint Review realizada
[ ] merge a main realizado
```

Con esto termina el Sprint 1.