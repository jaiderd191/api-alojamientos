
"""Scripts auxiliares del proyecto."""